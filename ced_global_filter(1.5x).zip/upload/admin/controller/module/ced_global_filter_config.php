<?php
/**
 * 
 */
class ControllerModuleCedGlobalFilterConfig extends Controller
{	
	private $helper;
	
	public function __construct($registry)
    {
        // pass `$registry` to parent `__construct`
        parent::__construct($registry);
    }
	public function index() { 
        $this->language->load('module/ced_global_filter_config');
        
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate())
        {
            if($this->request->post['ced_global_filter_config_status']) 
                $this->model_setting_setting->editSetting('module_ced_global_filter_config', ['module_ced_global_filter_config_status'=>1]);              
             else
                 $this->model_setting_setting->editSetting('module_ced_global_filter_config', ['module_ced_global_filter_config_status'=>0]);
            $this->model_setting_setting->editSetting('ced_global_filter_config', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'] , 'SSL'));
        }

        $developer_tabs = array('status');

        // Developer Settings
        foreach ($developer_tabs as $developer_tab) 
        {
            $this->data['entry_' . $developer_tab] = $this->language->get('entry_' . $developer_tab);

            if (isset($this->request->post['ced_global_filter_config_' . $developer_tab])) {
                $this->data['ced_global_filter_config_' . $developer_tab] = $this->request->post['ced_global_filter_config_' . $developer_tab];
            } else {
                $this->data['ced_global_filter_config_' . $developer_tab] = $this->config->get('ced_global_filter_config_' . $developer_tab);
            }
        }
        $this->data['breadcrumbs'] = array();

        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'separator'     => '',
            'href' => $this->url->link('common/home', 'token=' . $this->session->data['token'], true)
        );
        
        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_module'),
            'separator'     => ' :: ',
            'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'] . '&type=module', true)
        );

        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'separator'     => ' :: ',
            'href' => $this->url->link('module/ced_global_filter_config', 'token=' . $this->session->data['token'], true)
            );

        $this->data['token']= $this->session->data['token'];
        $this->data['action'] = $this->url->link('module/ced_global_filter_config', 'token=' . $this->session->data['token'], 'SSL');
        $this->data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'] . '&type=module', true);

        $this->data['heading_title'] = $this->language->get('heading_title');

		$this->data['text_enabled'] = $this->language->get('text_enabled');
		$this->data['text_disabled'] = $this->language->get('text_disabled');
		$this->data['text_content_top'] = $this->language->get('text_content_top');
		$this->data['text_content_bottom'] = $this->language->get('text_content_bottom');		
		$this->data['text_column_left'] = $this->language->get('text_column_left');
		$this->data['text_column_right'] = $this->language->get('text_column_right');

		$this->data['entry_limit'] = $this->language->get('entry_limit');
		$this->data['entry_image'] = $this->language->get('entry_image');
		$this->data['entry_layout'] = $this->language->get('entry_layout');
		$this->data['entry_position'] = $this->language->get('entry_position');
		$this->data['entry_status'] = $this->language->get('entry_status');
		$this->data['entry_sort_order'] = $this->language->get('entry_sort_order');

		$this->data['button_save'] = $this->language->get('button_save');
		$this->data['button_cancel'] = $this->language->get('button_cancel');
		$this->data['button_add_module'] = $this->language->get('button_add_module');
		$this->data['button_remove'] = $this->language->get('button_remove');

		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}

		if (isset($this->error['image'])) {
			$this->data['error_image'] = $this->error['image'];
		} else {
			$this->data['error_image'] = array();
		}
		$this->data['modules'] = array();

		if (isset($this->request->post['ced_global_filter_config'])) {
			$this->data['modules'] = $this->request->post['ced_global_filter_config'];
		} elseif ($this->config->get('ced_global_filter_config')) { 
			$this->data['modules'] = $this->config->get('ced_global_filter_config');
		}	

		$this->load->model('design/layout');

        $this->data['layouts'] = $this->model_design_layout->getLayouts();

		$this->template = 'module/ced_global_filter_config.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
        );
		$this->response->setOutput($this->render());
    }
    protected function validate() {
        if (!$this->user->hasPermission('modify', 'module/ced_global_filter_config')) {
            $this->data['error_warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }
    public function install() {
        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getId(), 'access', 'module/ced_global_filter_config');
        $this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'module/ced_global_filter_config');
        $this->model_user_user_group->addPermission($this->user->getId(), 'access', 'module/ced_global_filter');
        $this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'module/ced_global_filter');
    }
    public function uninstall() { 
        $this->db->query("DELETE FROM `".DB_PREFIX."setting` WHERE `group`='ced_global_filter'");
    }
}