<?php 

$_['heading_title'] 		= 'Global Filter By Cedcommerce';

$_['text_module'] 			= 'Modules';
$_['text_extension'] 		= 'Extension';
$_['text_installed'] 		= 'Global Filter module is now installed.';
$_['text_success']          = 'Global Filter module\'s Configuration saved Successfully.' ;
$_['text_edit']             = 'Edit Global Filter Settings';

// Developer Settings
$_['entry_status']			= 'Status';
   
?>