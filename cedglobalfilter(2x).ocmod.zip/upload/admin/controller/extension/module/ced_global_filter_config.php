<?php

/**
 * 
 */
class ControllerExtensionModuleCedGlobalFilterConfig extends Controller
{
	
	private $helper;
	
	public function __construct($registry)
    {
        // pass `$registry` to parent `__construct`
        parent::__construct($registry);
    }

    public function index() {
    	$this->load->language('extension/module/ced_global_filter_config');
        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate())
        {
            if($this->request->post['ced_global_filter_config_status'])
                $this->model_setting_setting->editSetting('module_ced_global_filter_config', ['module_ced_global_filter_config_status'=>1]);
            else
                $this->model_setting_setting->editSetting('module_ced_global_filter_config', ['module_ced_global_filter_config_status'=>0]);
            $this->model_setting_setting->editSetting('ced_global_filter_config', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] , true));
        }

        $developer_tabs = array('status');

        // Developer Settings
        foreach ($developer_tabs as $developer_tab) 
        {
            $data['entry_' . $developer_tab] = $this->language->get('entry_' . $developer_tab);

            if (isset($this->request->post['ced_global_filter_config_' . $developer_tab])) {
                $data['ced_global_filter_config_' . $developer_tab] = $this->request->post['ced_global_filter_config_' . $developer_tab];
            } else {
                $data['ced_global_filter_config_' . $developer_tab] = $this->config->get('ced_global_filter_config_' . $developer_tab);
            }
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'separator'     => '',
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'separator'     => ' :: ',
            'href' => $this->url->link('extension/module', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'separator'     => ' :: ',
            'href' => $this->url->link('extension/module/ced_global_filter_config', 'user_token=' . $this->session->data['user_token'], true)
            );
        $data['user_token']= $this->session->data['user_token'];

        $data['action'] = $this->url->link('extension/module/ced_global_filter_config', 'user_token=' . $this->session->data['user_token'], true);

        $data['cancel'] = $this->url->link('extension/module', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/ced_global_filter_config', $data));
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/ced_global_filter_config')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        return !$this->error;
    }

    public function install() {
            
        $this->load->model('user/user_group');
        
        $this->model_user_user_group->addPermission($this->user->getId(), 'access', 'extension/module/ced_global/filter');
        $this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'extension/module/ced_global/filter');

        $this->model_user_user_group->addPermission($this->user->getId(), 'access', 'extension/module/ced_global_filter_config');
        $this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'extension/module/ced_global_filter_config');
    }

    public function uninstall() { 
        $this->db->query("DELETE FROM `".DB_PREFIX."setting` WHERE code= 'ced_global_filter' ");
    }
}